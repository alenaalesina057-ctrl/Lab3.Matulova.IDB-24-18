﻿namespace OOP_L3.Models
{
    // DTO для книг
    public class BookDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public int Year { get; set; }
        public decimal Price { get; set; }
        public int AuthorId { get; set; }
        public string AuthorName { get; set; } = string.Empty;
        public List<CategorySimpleDto> Categories { get; set; } = new List<CategorySimpleDto>();
    }
    public class CreateBookDto
    {
        public string Title { get; set; } = string.Empty;
        public int Year { get; set; }
        public decimal Price { get; set; }
        public int AuthorId { get; set; }
        public List<int> CategoryIds { get; set; } = new List<int>();
    }
    public class BookSimpleDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public int Year { get; set; }
    }

    // DTO для категорий
    public class CategorySimpleDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
    public class CategoryFullDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int BooksCount { get; set; }
        public List<BookSimpleDto> Books { get; set; } = new List<BookSimpleDto>();
    }

    // DTO для авторов
    public class AuthorDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public List<BookSimpleDto> Books { get; set; } = new List<BookSimpleDto>();
    }

    // DTO для обновления
    public class AuthorUpdateDto
    {
        public string Name { get; set; } = string.Empty;
    }
    public class CategoryUpdateDto
    {
        public string Name { get; set; } = string.Empty;
    }
}
