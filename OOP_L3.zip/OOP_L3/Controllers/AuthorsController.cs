﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OOP_L3.Data;
using OOP_L3.Models;

namespace OOP_L3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AuthorsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult<AuthorDto>> CreateAuthor([FromBody] Author author)
        {
            _context.Authors.Add(author);
            await _context.SaveChangesAsync();

            var dto = new AuthorDto
            {
                Id = author.Id,
                Name = author.Name,
                Books = new List<BookSimpleDto>()
            };

            return CreatedAtAction(nameof(GetAuthor), new { id = author.Id }, dto);
        }

        [HttpGet]
        public async Task<ActionResult<List<AuthorDto>>> GetAuthors()
        {
            return await _context.Authors
                .Include(a => a.Books)
                .Select(a => new AuthorDto
                {
                    Id = a.Id,
                    Name = a.Name,
                    Books = a.Books.Select(b => new BookSimpleDto
                    {
                        Id = b.Id,
                        Title = b.Title,
                        Year = b.Year
                    }).ToList()
                })
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AuthorDto>> GetAuthor(int id)
        {
            var author = await _context.Authors
                .Where(a => a.Id == id)
                .Select(a => new AuthorDto
                {
                    Id = a.Id,
                    Name = a.Name,
                    Books = a.Books.Select(b => new BookSimpleDto
                    {
                        Id = b.Id,
                        Title = b.Title,
                        Year = b.Year
                    }).ToList()
                })
                .FirstOrDefaultAsync();

            if (author == null) return NotFound();
            return author;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAuthor(int id, [FromBody] AuthorUpdateDto dto)
        {
            var author = await _context.Authors.FindAsync(id);
            if (author == null) return NotFound();

            author.Name = dto.Name;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAuthor(int id)
        {
            var author = await _context.Authors.FindAsync(id);
            if (author == null) return NotFound();

            _context.Authors.Remove(author);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}