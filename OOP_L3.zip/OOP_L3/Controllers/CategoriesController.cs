﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OOP_L3.Data;
using OOP_L3.Models;

namespace OOP_L3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CategoriesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult> CreateCategory([FromBody] Category category)
        {
            _context.Categories.Add(category);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCategory), new { id = category.Id }, category);
        }

        [HttpGet]
        public async Task<ActionResult<List<CategoryFullDto>>> GetCategories()
        {
            return await _context.Categories
                .Select(c => new CategoryFullDto
                {
                    Id = c.Id,
                    Name = c.Name,
                    BooksCount = c.Books.Count,
                    Books = c.Books.Select(b => new BookSimpleDto
                    {
                        Id = b.Id,
                        Title = b.Title,
                        Year = b.Year
                    }).ToList()
                })
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<CategoryFullDto>> GetCategory(int id)
        {
            var category = await _context.Categories
                .Where(c => c.Id == id)
                .Select(c => new CategoryFullDto
                {
                    Id = c.Id,
                    Name = c.Name,
                    BooksCount = c.Books.Count,
                    Books = c.Books.Select(b => new BookSimpleDto
                    {
                        Id = b.Id,
                        Title = b.Title,
                        Year = b.Year
                    }).ToList()
                })
                .FirstOrDefaultAsync();

            if (category == null) return NotFound();
            return category;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCategory(int id, [FromBody] CategoryUpdateDto dto)
        {
            var category = await _context.Categories.FindAsync(id);
            if (category == null) return NotFound();

            category.Name = dto.Name;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            if (category == null) return NotFound();

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}