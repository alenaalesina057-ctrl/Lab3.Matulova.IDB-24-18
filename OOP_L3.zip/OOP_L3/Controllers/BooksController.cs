﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OOP_L3.Data;
using OOP_L3.Models;

namespace OOP_L3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly AppDbContext _context;

        public BooksController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult<BookDto>> CreateBook([FromBody] CreateBookDto dto)
        {
            var book = new Book
            {
                Title = dto.Title,
                Year = dto.Year,
                Price = dto.Price,
                AuthorId = dto.AuthorId
            };

            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            if (dto.CategoryIds != null && dto.CategoryIds.Count > 0)
            {
                foreach (var catId in dto.CategoryIds)
                {
                    await _context.Database.ExecuteSqlRawAsync(
                        "INSERT INTO BookCategory (BooksId, CategoriesId) VALUES ({0}, {1})",
                        book.Id, catId);
                }
            }

            var createdBook = await GetBookDto(book.Id);
            return CreatedAtAction(nameof(GetBook), new { id = book.Id }, createdBook);
        }

        [HttpGet]
        public async Task<ActionResult<List<BookDto>>> GetBooks()
        {
            var books = await _context.Books
                .Include(b => b.Author)
                .Include(b => b.Categories)
                .ToListAsync();

            return books.Select(b => MapToDto(b)).ToList();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<BookDto>> GetBook(int id)
        {
            var bookDto = await GetBookDto(id);
            if (bookDto == null) return NotFound();
            return bookDto;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBook(int id, [FromBody] CreateBookDto dto)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            book.Title = dto.Title;
            book.Year = dto.Year;
            book.Price = dto.Price;
            book.AuthorId = dto.AuthorId;

            await _context.Database.ExecuteSqlRawAsync(
                "DELETE FROM BookCategory WHERE BooksId = {0}", id);

            if (dto.CategoryIds != null && dto.CategoryIds.Count > 0)
            {
                foreach (var catId in dto.CategoryIds)
                {
                    await _context.Database.ExecuteSqlRawAsync(
                        "INSERT INTO BookCategory (BooksId, CategoriesId) VALUES ({0}, {1})",
                        id, catId);
                }
            }

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            await _context.Database.ExecuteSqlRawAsync(
                "DELETE FROM BookCategory WHERE BooksId = {0}", id);

            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private async Task<BookDto?> GetBookDto(int id)
        {
            var book = await _context.Books
                .Include(b => b.Author)
                .Include(b => b.Categories)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (book == null) return null;
            return MapToDto(book);
        }

        private BookDto MapToDto(Book book)
        {
            return new BookDto
            {
                Id = book.Id,
                Title = book.Title,
                Year = book.Year,
                Price = book.Price,
                AuthorId = book.AuthorId,
                AuthorName = book.Author?.Name ?? "Неизвестен",
                Categories = book.Categories.Select(c => new CategorySimpleDto
                {
                    Id = c.Id,
                    Name = c.Name
                }).ToList()
            };
        }
    }
}